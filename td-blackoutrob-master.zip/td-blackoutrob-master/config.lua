
Config = {}

Config.Ara = 5 --dokunmayınız

Config.LSPD = 1 -- Polis Sayısı

Config.pedloc = {
    { coords = vector3(150.03, -1684.22, 28.50), heading = 129.0},   --Satışta duran pedin lokasyonu
}  

