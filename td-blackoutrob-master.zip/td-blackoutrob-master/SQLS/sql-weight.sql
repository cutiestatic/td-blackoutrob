INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
('depo1', 'Benzin Deposu', 1, 0, 1),
('depo2', 'Dolu Benzin Deposu', 1, 0, 1),
('depo3', 'Kablo', 1, 0, 1),
('depo4', 'İşe Yarar Kablo', 1, 0, 1),