INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
('depo1', 'Benzin Deposu', 20, 0, 1),
('depo2', 'Dolu Benzin Deposu', 20, 0, 1),
('depo3', 'Kablo', 20, 0, 1),
('depo4', 'İşe Yarar Kablo', 20, 0, 1),
